
Web application "Phone book"
=======================================

Web service for storing contacts info.

User can register in the system and create/edit/delete storing records,
view them with the possibility of filtering by name/second name/phone number.

## Running phonebook locally
```
	git clone 
	cd Phone-Book https://github.com/anirudhgarg56/Backend_St3
	./mvnw spring-boot:run
	
```

## Database configuration

In case you want to run it with local postgres database
open PostgreSQL console editor and execute following commands
```       
    CREATE DATABASE phonebook;   
    CREATE USER bookuser WITH password 'password';     
    GRANT ALL privileges ON DATABASE phonebook TO bookuser; 
```
then go to project folder and execute
```
   ./mvnw spring-boot:run -Drun.jvmArguments="-Dspring.profiles.active=postgres" -P postgres 
```
You will find your running app at http://localhost:9696/phonebook 
